package t5demo.model;

/**
 * Role enumeration for the {@link User#getRole()}
 */
public enum Role {
	ADMIN, USER, GUEST
}
