package t5demo.components;

import org.apache.tapestry5.annotations.IncludeStylesheet;

/**
 * Border of the application
 */
@IncludeStylesheet("context:style.css")
public class Layout {

}
